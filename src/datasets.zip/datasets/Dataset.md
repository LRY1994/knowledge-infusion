# **Dataset**

We provide all datasets that we conduct experiment on in this work, which including four datasets: NaturalQuestion, WebQuestion, TriviaQA, SQuAD2.0. 

## NaturalQuestion

This dataset is only used when QA-tune.

**Format**

- Answer: The answer string obtained from the original NaturalQestion
- Question:  The question string

## WebQuestion

This dataset is only used when QA-tune.

**Format**

- Answer: The answer string obtained from the original WebQuestion
- Question:  The question string

## TriviaQA

This dataset is only used when QA-tune.

**Format**

- Answer: The answer string obtained from the original TriviaQA
- Question:  The question string

## SQuAD2.0

This dataset includes three data format: LM-tune-format, QA-tune-format, Bridge-tune-format.

**Format**

* LM-tune
  * Answer: The original paragraph from the SQuAD2.0
  * question: Masked paragraph from the SQuAD2.0
* QA-tune
  * Answer: The answer string obtained from the answer span of SQuAD2.0
  * question: The question string
* Bridge-tune
  * Answer: The answer string obtained from the answer span of SQuAD2.0 corresponding to its related paragraph.
  * Question: The question string